import "./App.css";
import React from "react";
import Message from "./components/message.component";
class App extends React.Component {
  // server
  msgs = ["Hello World !", "Hola World !", "Good Morning !", "Good Evening !"];

  render() {
    let theMsgsToBeCreated = this.msgs.map((m) => <Message themessage={m} />);
    return (
      <div id="AppDiv">
        {theMsgsToBeCreated}
        {/* <Message themessage={this.msg1} />
        <Message themessage={this.msg2} />
        <Message themessage={this.msg3} /> */}

        {/* <Message themessage="Good Morning !" />
        <Message themessage="Good Evening !" /> */}
      </div>
    );
  }
}

export function Add(x, y) {
  return x + y;
}

export default App;

export const PI = 3.14;
