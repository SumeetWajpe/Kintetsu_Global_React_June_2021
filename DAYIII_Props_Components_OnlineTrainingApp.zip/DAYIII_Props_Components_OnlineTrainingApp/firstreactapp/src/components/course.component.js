import React from "react";

class Course extends React.Component {
  render() {
    return <h2>{this.props.name}</h2>;
  }
}

export default Course;
