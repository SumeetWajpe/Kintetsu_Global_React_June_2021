import React from "react";
import Course from "./course.component";
class ListOfCourses extends React.Component {
  courses = ["React", "Angular", "Vue"];
  render() {
    let coursesToBeCreated = this.courses.map((course) => (
      <Course name={course} />
    ));
    return (
      <div>
        {/* Should have header component */}
        <h1> List Of Courses</h1> {coursesToBeCreated}
      </div>
    );
  }
}

export default ListOfCourses;
