import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App, { PI, Add } from "./App";

ReactDOM.render(<App />, document.getElementById("root"));
