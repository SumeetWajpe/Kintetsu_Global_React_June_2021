import React from "react";

class Course extends React.Component {
  render() {
    return (
      <div>
        <h2>{this.props.coursedetails.name}</h2> <strong>Price : </strong>{" "}
        {this.props.coursedetails.price}
      </div>
    );
  }
}

export default Course;
