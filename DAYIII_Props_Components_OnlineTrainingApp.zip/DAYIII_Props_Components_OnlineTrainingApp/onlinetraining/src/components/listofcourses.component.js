import React from "react";
import Course from "./course.component";
class ListOfCourses extends React.Component {
  courses = [
    { name: "React", price: 5000 },
    { name: "Angular", price: 6000 },
    { name: "Vue", price: 7000 },
  ];
  render() {
    let coursesToBeCreated = this.courses.map((course) => (
      <Course coursedetails={course} />
    ));
    return (
      <div>
        {/* Should have header component */}
        <h1> List Of Courses</h1> {coursesToBeCreated}
      </div>
    );
  }
}

export default ListOfCourses;
