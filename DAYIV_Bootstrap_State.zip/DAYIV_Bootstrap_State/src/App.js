import "./App.css";
import React from "react";
import ListOfCourses from "./components/listofcourses.component";

class App extends React.Component {
  render() {
    return (
      <div className="container">
        <ListOfCourses />
      </div>
    );
  }
}
export default App;
