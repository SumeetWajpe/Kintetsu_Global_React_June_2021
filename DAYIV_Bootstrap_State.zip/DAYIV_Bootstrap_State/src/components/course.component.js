import React from "react";

class Course extends React.Component {
  constructor() {
    super();
    this.state = { currLikes: 2000 };
  }
  IncrementLikes() {
    console.log("U Clicked !");
    // this.props.coursedetails.likes += 1; // props are readonly !
  }
  render() {
    return (
      <div className="col-sm-6 col-md-4">
        <div className="card m-2">
          <img
            src={this.props.coursedetails.imageUrl}
            alt={this.props.coursedetails.name}
            height="200px"
            width="250px"
            className="card-img-top"
          />
          <div className="card-body">
            <h2 className="card-title">{this.props.coursedetails.name}</h2>
            <h4>Price : {this.props.coursedetails.price} </h4>
            {/* <h4>Likes : {this.props.coursedetails.likes} </h4>
             */}

            <h4>Likes : {this.state.currLikes} </h4>
            <h4>Rating : {this.props.coursedetails.rating} </h4>
            <button
              className="btn btn-primary m-1"
              // onClick={() => this.IncrementLikes()}
              onClick={this.IncrementLikes.bind(this)}
            >
              Likes ++
            </button>
            <button className="btn btn-danger">Delete</button>
          </div>
        </div>
      </div>
    );
  }
}

export default Course;
