import axios from "axios";

export function IncrementLikes(courseId) {
  return { type: "INCREMENT_LIKES", courseId };
}

export function DeleteCourse(courseId) {
  return { type: "DELETE_COURSE", courseId };
}
export function DeletePost() {
  return { type: "DELETE_POST" };
}

export function FetchAllPosts(postsFromServer) {
  return { type: "FETCH_ALL_POSTS", postsFromServer };
}

export function FetchAllPostsAsync() {
  return (dispatch) => {
    // ajax
    let APromise = axios.get("https://jsonplaceholder.typicode.com/posts");
    APromise.then((response) => {
      dispatch(FetchAllPosts(response.data));
    });
  };
}
