import { BrowserRouter, Switch, Route, Redirect, Link } from "react-router-dom";

import ListOfCourses from "./listofcourses.component";
import SummaryOfCourses from "./coursessummary.component";
import Posts from "./posts.component";
import PostDetails from "./postdetails.component";

import "./App.css";
import NewCourse from "./newcourse.component";

function App(props) {
  // console.log(props);
  return (
    <BrowserRouter>
      <div className="container">
        {/* <a href="/">Home</a> | 
          <a href="/posts">Posts</a> | 
          <a href="/postseffect">Posts With Effect</a> */}

        <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <div className="container-fluid">
            <Link className="navbar-brand" to="/">Online Tuts</Link>
            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
              <div className="navbar-nav">
                <Link className="nav-link active" aria-current="page" to="/">Courses</Link>
                <Link className="nav-link" to="/newcourse">New Course</Link>

                <Link className="nav-link" to="/posts">Posts</Link>

              </div>
            </div>
          </div>
        </nav>

        <Switch>
          <Route path="/" exact>
            <SummaryOfCourses {...props} />
            <ListOfCourses {...props} />
          </Route>
          <Route path="/posts" >
            <Posts {...props} />
          </Route>
          <Route component={NewCourse}></Route>
          {/* <Route path="/postdetails/:pid" component={PostDetails}></Route> */}

          {/* <Route path="/postdetails/:pid" >
            <PostDetails {...props} />
          </Route> */}
          <Route path="/postdetails/:pid" render={(routerProps) => <PostDetails {...props} {...routerProps} />} ></Route>



          <Route path="**" render={() => <Redirect to="/" />}></Route>

        </Switch>
      </div>
    </BrowserRouter >
  );
}

export default App;
