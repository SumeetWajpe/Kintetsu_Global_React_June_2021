import React from 'react'

const SummaryOfCourses = (props) => {
    return (
        <div >
            <h2>Summary Of Courses</h2>
            <ul className="list-group col-md-2">{
                props.allCourses.map(c => <li className="list-group-item">{c.name} - {c.likes} </li>)
            } </ul>
        </div>
    )
}

export default SummaryOfCourses;