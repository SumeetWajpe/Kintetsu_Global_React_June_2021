import React from 'react'
import Course from './course.component';

const ListOfCourses = (props) => {
    console.log(props);
    let coursesToBeCreated = props.allCourses.map((course) => (
        <Course
            key={course.id}
            coursedetails={course}
            {...props}
        />
    ));
    return (
        <div className="row">
            {/* Should have header component */}
            <h1> List Of Courses</h1> {coursesToBeCreated}
        </div>
    );
}

export default ListOfCourses