import React from 'react'

const NewCourse = (props) => {
    return (
        <div>
            Id : <input type="text" />
        </div>
    )
}

export default NewCourse