import React from 'react'

const PostDetails = (props) => {
    console.log(props);
    // const { match: { params: { pid } } } = props;
    const pid = +(props.match.params.pid);
    const thePost = props.allPosts.find(p => p.id === pid);
    return (
        <div>
            <h1>Post Details for {thePost.id} </h1>
            <div className="card">
                <div className="card-body">
                    <h5 className="card-title">Title : {thePost.title}</h5>
                    <h6 className="card-subtitle mb-2 text-muted">Id : {thePost.id}</h6>
                    <p className="card-text">Body : {thePost.body}</p>
                </div>
            </div>
        </div>
    )
}

export default PostDetails;