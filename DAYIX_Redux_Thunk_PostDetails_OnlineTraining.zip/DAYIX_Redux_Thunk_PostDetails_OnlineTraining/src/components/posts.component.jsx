import React from 'react'
import { useEffect } from 'react';
import { Link } from 'react-router-dom';
const Posts = (props) => {
    let postsToBeCreated = props.allPosts.map(post => <li className="list-group-item" key={post.id}><Link to={"/postdetails/" + post.id}>{post.title}</Link> </li>)
    let content;
    if (postsToBeCreated.length > 0) {
        content = <ul className="list-group">
            {postsToBeCreated}
        </ul>
    } else {
        content = "Loading Posts..";
    }

    useEffect(() => {
        if (props.allPosts.length === 0) {
            props.FetchAllPostsAsync();
        }
    }, []);

    return (

        <div>
            <h1> All Posts</h1>
            {content}
        </div>
    )
}

export default Posts;