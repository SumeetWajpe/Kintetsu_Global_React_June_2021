export function courses(defStore = [], action) {
  let index;
  switch (action.type) {
    case "INCREMENT_LIKES":
      // console.log("Within Courses reducer !");
      // console.log(action);
      // console.log(defStore);
      index = defStore.findIndex((c) => c.id === action.courseId);
      return [
        ...defStore.slice(0, index),
        { ...defStore[index], likes: defStore[index].likes + 1 },
        ...defStore.slice(index + 1),
      ];
    case "DELETE_COURSE":
      index = defStore.findIndex((c) => c.id === action.courseId);
      return [...defStore.slice(0, index), ...defStore.slice(index + 1)];
    default:
      return defStore;
  }
}
