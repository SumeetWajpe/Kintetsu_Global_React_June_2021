import CourseModel from "../model/course.model";
import rootReducer from "../reducers/rootReducer";
import { createStore, applyMiddleware } from "redux";
import ReduxThunk from "redux-thunk";

let defaultStoreData = {
  courses: [
    new CourseModel(
      1,
      "React",
      5000,
      200,
      "https://miro.medium.com/max/3840/1*yjH3SiDaVWtpBX0g_2q68g.png",
      5
    ),
    new CourseModel(
      2,
      "Redux",
      6000,
      500,
      "https://redux.js.org/img/redux-logo-landscape.png",
      4
    ),
    new CourseModel(
      3,
      "Angular",
      3000,
      100,
      "https://miro.medium.com/max/480/1*9A6E9kaZZ54idy0HLSlh-A.png",
      3
    ),
    new CourseModel(
      4,
      "Vue",
      5000,
      500,
      "https://res.cloudinary.com/practicaldev/image/fetch/s--RgTOJxWn--/c_imagga_scale,f_auto,fl_progressive,h_720,q_auto,w_1280/https://thepracticaldev.s3.amazonaws.com/i/d440mmj72v2vi7ad76ir.png",
      5
    ),
    new CourseModel(
      5,
      "Flutter",
      8000,
      200,
      "https://flutter.dev/images/flutter-logo-sharing.png",
      5
    ),
  ],
  posts: [],
};

// let store = createStore(
//   rootReducer,
//   defaultStoreData,
//   window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
// );

let store = createStore(
  rootReducer,
  defaultStoreData,
  applyMiddleware(ReduxThunk)
);
export default store;
