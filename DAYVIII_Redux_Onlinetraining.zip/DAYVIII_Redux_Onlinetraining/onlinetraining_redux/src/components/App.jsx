import "./App.css";
import ListOfCourses from "./listofcourses.component";
import SummaryOfCourses from "./coursessummary.component";
import Posts from "./posts.component";
import { BrowserRouter, Switch, Route, Redirect, Link } from "react-router-dom";

function App(props) {
  // console.log(props);
  return (
    <BrowserRouter>
      <div className="container">
        {/* <a href="/">Home</a> | 
          <a href="/posts">Posts</a> | 
          <a href="/postseffect">Posts With Effect</a> */}

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container-fluid">
            <Link class="navbar-brand" to="/">Online Tuts</Link>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
              <div class="navbar-nav">
                <Link class="nav-link active" aria-current="page" to="/">Courses</Link>
                <Link class="nav-link" to="/posts">Posts</Link>
              </div>
            </div>
          </div>
        </nav>

        <Switch>
          <Route path="/" exact>
            <SummaryOfCourses {...props} />
            <ListOfCourses {...props} />
          </Route>
          <Route path="/posts" >
            <Posts {...props} />
          </Route>
          {/* <Route path="/postdetails/:pid" component={PostDetails}></Route> */}


          <Route path="**" render={() => <Redirect to="/" />}></Route>

        </Switch>
      </div>
    </BrowserRouter>
  );
}

export default App;

{/* <div>
      <SummaryOfCourses {...props} />
      <ListOfCourses {...props} />
    </div> */}