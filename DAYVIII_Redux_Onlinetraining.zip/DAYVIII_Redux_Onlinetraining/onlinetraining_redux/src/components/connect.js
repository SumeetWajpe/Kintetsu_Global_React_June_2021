import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as AllActions from "../actions/actionsCreators";
import App from "./App";

function mapStateToProps(store) {
  return {
    allCourses: store.courses,
    allPosts: store.posts,
  };
}

function mapDispatchToProps(dispatcher) {
  return bindActionCreators(AllActions, dispatcher);
}
let MainApp = connect(mapStateToProps, mapDispatchToProps)(App);
export default MainApp;
