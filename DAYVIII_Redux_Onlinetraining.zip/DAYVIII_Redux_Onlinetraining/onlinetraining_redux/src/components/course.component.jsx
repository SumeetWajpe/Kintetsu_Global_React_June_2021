import React from 'react'

const Course = (props) => {
    return (
        <div className="col-sm-6 col-md-4">
            <div className="card m-2">
                <img
                    src={props.coursedetails.imageUrl}
                    alt={props.coursedetails.name}
                    height="200px"
                    width="250px"
                    className="card-img-top"
                />
                <div className="card-body">
                    <h2 className="card-title">{props.coursedetails.name}</h2>
                    <h5>Price : {props.coursedetails.price} </h5>

                    <h5>Likes : {props.coursedetails.likes} </h5>
                    <h5>Rating : {props.coursedetails.rating} </h5>
                    <button
                        className="btn btn-primary m-1"
                        onClick={() => props.IncrementLikes(props.coursedetails.id)}
                    >
                        Likes ++
                    </button>
                    <button
                        className="btn btn-danger"
                        onClick={() => props.DeleteCourse(props.coursedetails.id)}
                    >
                        Delete
                    </button>
                </div>
            </div>
        </div>
    );
}

export default Course;