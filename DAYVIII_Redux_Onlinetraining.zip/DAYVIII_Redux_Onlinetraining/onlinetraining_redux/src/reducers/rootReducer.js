import { combineReducers } from "redux";
import { posts } from "./posts.reducer";
import { courses } from "./courses.reducer";

let rootReducer = combineReducers({ courses, posts });
export default rootReducer;
