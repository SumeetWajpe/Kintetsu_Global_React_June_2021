export function IncrementLikes() {
  return { type: "INCREMENT_LIKES" };
}

export function DeleteCourse() {
  return { type: "DELETE_COURSE" };
}
