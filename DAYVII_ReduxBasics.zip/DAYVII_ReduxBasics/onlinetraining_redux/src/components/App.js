import "./App.css";
import ListOfCourses from "./listofcourses.component";

function App(props) {
  // console.log(props);
  return (
    <div>
      <ListOfCourses {...props} />
    </div>
  );
}

export default App;
