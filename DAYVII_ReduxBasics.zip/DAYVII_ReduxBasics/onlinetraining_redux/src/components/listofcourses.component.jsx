import React from 'react'

const ListOfCourses = (props) => {
    console.log(props);
    return (
        <div>
            <h1>List Of Courses</h1>
        </div>
    )
}

export default ListOfCourses