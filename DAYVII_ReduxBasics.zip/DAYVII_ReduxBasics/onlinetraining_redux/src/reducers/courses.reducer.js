export function courses(defStore = [], action) {
  console.log("Within Courses reducer !");
  return defStore; // should return new store
}
