export function posts(defStore = [], action) {
  console.log("Within Posts reducer !");
  return defStore; // should return new store
}
