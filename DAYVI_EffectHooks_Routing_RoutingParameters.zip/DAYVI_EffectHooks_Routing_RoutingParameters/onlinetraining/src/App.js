import "./App.css";
import React from "react";
import { BrowserRouter, Switch, Route, Redirect, Link } from "react-router-dom";

import ListOfCourses from "./components/listofcourses.component";
import Posts from "./components/posts.component";
import Counter from "./components/functionalBasics";
import PostsWithEffect from "./components/postswithEffect";
import Message from "./components/message.component";
import PostDetails from "./components/post.details";
class App extends React.Component {
  render() {
    return (
      <BrowserRouter>
        <div className="container">
          {/* <a href="/">Home</a> | 
          <a href="/posts">Posts</a> | 
          <a href="/postseffect">Posts With Effect</a> */}
          <Link to="/">Home</Link> |<Link to="/posts">Post</Link> |
          <Link to="/postseffect">Posts With Effect</Link> |
          <Link to="/msg">Message</Link> |
          <Switch>
            <Route path="/" component={ListOfCourses} exact></Route>
            <Route path="/posts" component={Posts}></Route>
            <Route path="/postdetails/:pid" component={PostDetails}></Route>

            <Route path="/postseffect" component={PostsWithEffect}></Route>
            <Route path="/msg" render={() => <Message msg="Hello !" />}></Route>

            <Route path="**" render={() => <Redirect to="/" />}></Route>
            {/* <Route
              path="**"
              render={() => (
                <h1 style={{ color: "red" }}>404 ! Resource not found !</h1>
              )}
            ></Route> */}
          </Switch>
        </div>
      </BrowserRouter>
    );
  }
}
export default App;
