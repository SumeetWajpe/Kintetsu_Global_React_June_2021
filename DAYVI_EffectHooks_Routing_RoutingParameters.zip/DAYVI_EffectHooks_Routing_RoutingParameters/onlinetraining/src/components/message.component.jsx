import React from 'react'

export const Message = (props) => {
    return (
        <h1>
            {props.msg}
        </h1>
    )
}

export default Message;