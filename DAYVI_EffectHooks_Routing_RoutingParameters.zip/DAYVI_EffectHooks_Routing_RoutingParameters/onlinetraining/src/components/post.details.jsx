import React from 'react'

export const PostDetails = (props) => {
    // console.log(props.match.params.pid);
    const { match: { params: { pid } } } = props;
    return (
        <div>
            Post Details for {pid} here...
        </div>
    )
}

export default PostDetails