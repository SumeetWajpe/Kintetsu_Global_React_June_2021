import axios from 'axios';
import React, { useEffect, useState } from 'react'

export const PostsWithEffect = (props) => {

    let [allPosts, setAllPosts] = useState([]);

    useEffect(() => {
        console.log('Within Effect !');
        let APromise = axios.get('https://jsonplaceholder.typicode.com/posts');
        APromise.then(response => setAllPosts(response.data));
    }, []);
    console.log('Rendering JSX !');
    let allPostsToBeCreated = allPosts.map(post => <li key={post.id}>{post.title}</li>)
    return (
        <React.Fragment>
            <h1>All Posts</h1>
            <ul>
                {allPostsToBeCreated}
            </ul>
        </React.Fragment>
    )
}

export default PostsWithEffect;