import "./App.css";
import React from "react";
import ListOfCourses from "./components/listofcourses.component";
import Posts from "./components/posts.component";
import Counter from "./components/functionalBasics";

class App extends React.Component {
  render() {
    return (
      <div className="container">
        {/* <ListOfCourses /> */}
        {/* <Posts /> */}
        <Counter />
      </div>
    );
  }
}
export default App;
