import React, { useState } from 'react'

// var FunctionalComponent = function () {
//     return (
//         <div>
//             <h1>Functional Component</h1>
//         </div>
//     )
// }

/*
Restrictions
1. this is not available
2. no state | setState() - State Hooks (16.8)+
3. No LifeCycle Methods - Effects (16.8)+
4. no Render method
*/



function Counter(props) {
    let [count, changeMyCount] = useState({ currentCount: 0 });// return an array [initialState,methodToMutateThatState]
    let [age, changeMyAge] = useState(29);
    return (
        <div>
            <h1>{count.currentCount}</h1>
            <h1>{age}</h1>

            <input type="button" value="++" className="btn btn-primary" onClick={
                () => changeMyCount({ currentCount: count.currentCount + 1 })
            } />
            <input type="button" value="++" className="btn btn-primary" onClick={
                () => changeMyAge(age + 10)
            } />
        </div>
    )
} export default Counter;