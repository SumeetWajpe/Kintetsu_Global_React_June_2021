import React from 'react';
import axios from 'axios';


class Posts extends React.Component {
    constructor(props) {
        super(props);
        this.state = { allPosts: [] };
    }
    render() {
        let postsToBeCreated = this.state.allPosts.map(post => <li key={post.id}>{post.title}</li>)
        let content;
        if (postsToBeCreated.length > 0) {
            content = <ul>
                {postsToBeCreated}
            </ul>
        } else {
            content = "Loading Posts..";
        }
        return <div>
            <h1> All Posts</h1>
            {content}
        </div>
    }
    componentDidMount() {
        let APromise = axios.get('https://jsonplaceholder.typicode.com/posts');
        APromise.then(response => this.setState({ allPosts: response.data }));


    }
}

export default Posts;